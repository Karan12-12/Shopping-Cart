import React, { useState, useEffect } from "react";
import "./App.css";
import Cart from "./cart";
import Navbar from "./Navbar";
import {
  getFirestore,
  collection,
  onSnapshot,
  addDoc,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";
import firebaseApp from "./App";

function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const db = getFirestore(firebaseApp);
    const dbRef = collection(db, "products");
    const unsubscribe = onSnapshot(dbRef, (querySnapshot) => {
      const loadedProducts = querySnapshot.docs.map((doc) => ({
        ...doc.data(),
        id: doc.id,
      }));
      setProducts(loadedProducts);
      setLoading(false);
    });

    // Cleanup function to unsubscribe from snapshot listener
    return () => {
      unsubscribe();
    };
  }, []);

  const handleIncreaseQuantity = async (productId) => {
    const productToUpdate = products.find((p) => p.id === productId);
    const db = getFirestore(firebaseApp);
    const docRef = doc(db, "products", productId);
    await updateDoc(docRef, {
      qty: productToUpdate.qty + 1,
    });
  };

  const handleDecreaseQuantity = async (productId) => {
    const productToUpdate = products.find((p) => p.id === productId);
    if (productToUpdate.qty === 0) {
      return;
    }
    const db = getFirestore(firebaseApp);
    const docRef = doc(db, "products", productId);
    await updateDoc(docRef, {
      qty: productToUpdate.qty - 1,
    });
  };

  const handleDeleteProduct = async (productId) => {
    const db = getFirestore(firebaseApp);
    const docRef = doc(db, "products", productId);
    await deleteDoc(docRef);
  };

  const totalCartPrice = products.reduce(
    (total, product) => total + product.price * product.qty,
    0
  );

  const totalCartItems = products.reduce(
    (total, product) => total + product.qty,
    0
  );

  const addProduct = async () => {
    const db = getFirestore(firebaseApp);
    await addDoc(collection(db, "products"), {
      img: "",
      title: "washing machine",
      price: 999,
      qty: 4,
    });
  };

  return (
    <div className="App">
      <Navbar count={totalCartItems} />
      {/* <button onClick={addProduct} style={{ padding: 20, fontSize: 20 }}>
        Add a product
      </button> */}
      <Cart
        products={products}
        onIncreaseQuantity={handleIncreaseQuantity}
        onDecreaseQuantity={handleDecreaseQuantity}
        onDeleteProduct={handleDeleteProduct}
      />
      {loading && <h1>Loading products...</h1>}
      <div style={{ padding: 10, fontSize: 20 }}>TOTAL:{totalCartPrice}</div>
    </div>
  );
}

export default App;
